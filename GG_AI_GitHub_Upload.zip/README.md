# GG AI v1

A starter MVP for a football Both Teams To Score (GG/BTTS) analysis engine.

## Stack
- Python + FastAPI
- PostgreSQL-ready schema (SQLite is used for local zero-cost development)
- SQLAlchemy
- Pydantic
- Requests
- Scikit-learn-ready architecture

## What v1 does
1. Fetches today's fixtures from API-Football.
2. Stores fixtures in the database.
3. Builds a baseline GG score from recent/team statistics.
4. Returns ranked GG candidates.
5. Stores predictions so actual results can be evaluated later.

## Important
This is an analytics prototype, not a guarantee of betting outcomes. Probabilities must be backtested and calibrated before being treated as reliable.

## Setup

1. Install Python 3.11+.
2. Create a virtual environment.
3. Install dependencies:

   pip install -r requirements.txt

4. Copy `.env.example` to `.env`.
5. Add your API-Football key.
6. Start the API:

   uvicorn app.main:app --reload

7. Open:
   http://127.0.0.1:8000/docs

For a first local test, SQLite is used automatically. PostgreSQL can be enabled with DATABASE_URL.

## Real-data validation

Before production:
1. Obtain an API-Football key privately.
2. Collect historical pre-match features, not post-match statistics.
3. Save them in chronological order.
4. Run train/validation/test splits.
5. Evaluate accuracy, Brier score, log loss and calibration.
6. Only then tune the model and publish predictions.

Never use final-match statistics as inputs to a pre-match prediction; that would create data leakage.
