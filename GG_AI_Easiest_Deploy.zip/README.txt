GG AI easiest deployment package. Upload app.py, requirements.txt and render.yaml to GitHub, then connect the repository to Render.
