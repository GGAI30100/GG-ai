import math
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware

app=FastAPI(title="GG AI",version="1.0")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_methods=["*"],allow_headers=["*"])

def gg_probability(hg,ha,ag,aa):
    hl=max(.05,(hg+aa)/2); al=max(.05,(ag+ha)/2)
    return round(max(0,min(1,(1-math.exp(-hl))*(1-math.exp(-al))))*100,2)

DEMO=[
("Team A","Team B",1.8,1.2,1.6,1.4),
("Team C","Team D",1.7,1.3,1.5,1.4),
("Team E","Team F",1.6,1.3,1.45,1.45)]

@app.get("/health")
def health(): return {"status":"ok","app":"GG AI","version":"1.0"}

@app.get("/api/top")
def top():
    rows=[]
    for i,(h,a,hg,ha,ag,aa) in enumerate(DEMO,1):
        p=gg_probability(hg,ha,ag,aa)
        rows.append({"rank":i,"home":h,"away":a,"gg_probability":p,
                     "gg_score":round(.75*p+20,2),"confidence":80,
                     "label":"PREMIUM" if p>=80 else "STRONG"})
    return sorted(rows,key=lambda x:x["gg_probability"],reverse=True)

@app.get("/",response_class=HTMLResponse)
def dashboard():
    return """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<title>GG AI</title><style>
body{font-family:Arial;margin:0;background:#f4f6f8;color:#15202b}
header{background:#101828;color:white;padding:22px;text-align:center}
main{max-width:700px;margin:20px auto;padding:0 14px}
.card{background:white;margin:14px 0;padding:20px;border-radius:16px;box-shadow:0 2px 12px #0001}
.p{font-size:34px;font-weight:800}.muted{color:#667085}
.badge{float:right;background:#e7f6ec;padding:6px 10px;border-radius:20px;font-size:12px;font-weight:bold}
</style></head><body><header><h2>⚽ GG AI</h2><div>🔥 Top GG Today</div></header>
<main><p class="muted">AI-assisted Both Teams To Score analysis</p><div id="list">Loading...</div></main>
<script>fetch('/api/top').then(r=>r.json()).then(d=>{document.getElementById('list').innerHTML=d.map(x=>`<div class="card"><span class="badge">${x.label}</span><h3>${x.home} vs ${x.away}</h3><div class="p">${x.gg_probability}%</div><div class="muted">GG probability · Confidence ${x.confidence}% · Score ${x.gg_score}/100</div></div>`).join('')})</script>
</body></html>"""
